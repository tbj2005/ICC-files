#!/bin/bash 

python -m vllm.entrypoints.api_server --model /data2/share/llama/llama-2-7b-chat-hf
