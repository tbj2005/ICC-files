average len of prompt in shareGPT: 102
average len of prompt in alpaca: 21.7