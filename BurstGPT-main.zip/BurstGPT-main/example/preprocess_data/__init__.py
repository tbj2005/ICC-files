from preprocess_data.load_data import load_data_from_path

__all__ = ["load_data_from_path"]